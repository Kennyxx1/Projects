<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ybc_blog_free}prestashop>blog_list_59526bf44608558c7a7331e99f4b8038'] = 'Neueste Beiträge';
$_MODULE['<{ybc_blog_free}prestashop>blog_list_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Bemerkungen';
$_MODULE['<{ybc_blog_free}prestashop>blog_list_16_59526bf44608558c7a7331e99f4b8038'] = 'Neueste Beiträge';
$_MODULE['<{ybc_blog_free}prestashop>gallery_03904e973e81c46dfc62dcc40779d51e'] = 'Bildergalerie';
$_MODULE['<{ybc_blog_free}prestashop>gallery_16_03904e973e81c46dfc62dcc40779d51e'] = 'Bildergalerie';
$_MODULE['<{ybc_blog_free}prestashop>categories_block_3cfd94e5b1e020a2b88c15f49d57886e'] = 'Blog-Kategorien';
$_MODULE['<{ybc_blog_free}prestashop>featured_posts_block_17fe63a5060231fe0c7e84a0528bc7fd'] = 'Beliebte Beiträge';
$_MODULE['<{ybc_blog_free}prestashop>latest_posts_block_59526bf44608558c7a7331e99f4b8038'] = 'Neueste Beiträge';
$_MODULE['<{ybc_blog_free}prestashop>popular_posts_block_0422ae5ca6429121fc69c4eb1c643b32'] = 'Beliebte Beiträge';
