<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ets_megamenu}prestashop>ets_megamenu_968c8ef65d5d5d87254964b78a2e02f5'] = 'Mega Menu PRO';
