=== Easy Maps Block ===
Contributors: boldgrid, rramo012
Tags: boldgrid, map, google
Requires at least: 5.0
Tested up to: 6.6
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Insert a Google Map into the Gutenberg editor.

== Installation ==

= Minimum Requirements =

* WordPress 5.0 or greater

= From within WordPress =
1. Visit 'Plugins > Add New'
1. Search for 'Map Block'
1. Activate Map Block from your Plugins page.

= Manually =
1. Upload the entire map-block folder to the /wp-content/plugins/ directory.
1. Activate the plugin through the Plugins menu in WordPress.

= 1.0.1 =
* Fix: Added button to assit with opening controls when clicking map.

= 1.0 =
* Initial public release.
